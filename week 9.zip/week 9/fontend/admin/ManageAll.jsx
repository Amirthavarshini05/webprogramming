import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function ManageTVShow() {
  const [tvShows, setTvShows] = useState({});
  const [filterStatus, setFilterStatus] = useState("All Statuses");
  const [selectedShow, setSelectedShow] = useState({});
  const [editShow, setEditShow] = useState({});
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    title: "",
    genre: "",
    status: "Ongoing",
    watchedEpisodes: "",
    totalEpisodes: "",
    rating: "",
  });

  const navigate = useNavigate();

  // ✅ Fetch all shows
  const fetchShows = async (e) => {
    try {
      const response = await axios.get("http://localhost:4000/api/tvshows");
      setTvShows(response.data);
    } catch (error) {
      console.error("Error fetching TV shows:", error);
    }
  };

  useEffect(() => {
    fetchShows();
  }, []);

  const handleFilterChange = (e) => {
    setFilterStatus(e.target.value);
  };
  // ✅ Delete selected show
  const handleDelete = async () => {
    if (!selectedShow) return alert("Please select a show first!");
    if (!window.confirm("Are you sure you want to delete this show?")) return;

    try {
      await axios.delete(`http://localhost:4000/api/tvshows/${selectedShow._id}`);
      setSelectedShow(null);
      fetchShows();
    } catch (error) {
      console.error("Error deleting TV show:", error);
    }
  };

  // ✅ Edit selected show
  const handleEdit = () => {
    if (!selectedShow) return alert("Please select a show first!");
    setEditShow(selectedShow._id);
    setFormData({
      title: selectedShow.title,
      genre: selectedShow.genre,
      status: selectedShow.status,
      watchedEpisodes: selectedShow.watchedEpisodes,
      totalEpisodes: selectedShow.totalEpisodes,
      rating: selectedShow.rating,
    });
  };

  // ✅ Handle input changes for edit form
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // ✅ Validate form before updating
  const validate = () => {
    const newErrors = {};
    if (!formData.title.trim()) newErrors.title = "Title is required";
    if (!formData.genre.trim()) newErrors.genre = "Genre is required";
    if (!formData.totalEpisodes || formData.totalEpisodes < 1)
      newErrors.totalEpisodes = "Total episodes must be at least 1";
    return newErrors;
  };

  // ✅ Save updated data
  const handleUpdate = async (e) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    try {
      await axios.put(`http://localhost:4000/api/tvshows/${editShow}`, formData);
      alert("TV Show updated successfully!");
      setEditShow(null);
      setSelectedShow(null);
      fetchShows();
      setErrors({});
    } catch (error) {
      console.error("Error updating show:", error);
      setErrors({ api: "Failed to update show. Try again later." });
    }
  };

  // ✅ Filtered shows
  const filteredShows = tvShows.filter((show) => {
    if (filterStatus === "All Statuses") return true;
    return show.status === filterStatus;
  });

  return (
    <div style={{ padding: "20px" }}>
      <h2>Manage TV Shows</h2>

      {/* Buttons */}
      <div style={{ marginBottom: "15px" }}>
        <button onClick={() => navigate("/createtvshow")}>➕ Add TV Show</button>
        <button onClick={handleEdit} style={{ marginLeft: "10px" }}>
          ✏️ Edit Selected
        </button>
        <button onClick={handleDelete} style={{ marginLeft: "10px" }}>
          🗑 Delete Selected
        </button>
        <button onClick={() => navigate("/login")} style={{ marginLeft: "10px" }}>
          🚪 Logout
        </button>
      </div>

      {/* Filter Dropdown */}
      <select
        value={filterStatus}
        onChange={handleFilterChange}
        style={{ marginBottom: "20px" }}
      >
        <option>All Statuses</option>
        <option>Ongoing</option>
        <option>Completed</option>
      </select>

      {/* TV Show Table */}
      <table border="1" cellPadding="8" cellSpacing="0" style={{ width: "100%" }}>
        <thead>
          <tr>
            <th>Select</th>
            <th>Title</th>
            <th>Genre</th>
            <th>Status</th>
            <th>Progress</th>
            <th>Rating</th>
          </tr>
        </thead>
        <tbody>
            
          {filteredShows.length === 0 ? (
            <tr>
              <td colSpan="6" style={{ textAlign: "center" }}>
                No TV shows found
              </td>
            </tr>
          ) : (
            filteredShows.map((show, index) => (
              <tr key={index}>
                <td>
                  <input
                    type="radio"
                    name="selectedShow"
                    onChange={() => setSelectedShow(show)}
                    checked={selectedShow?._id === show._id}
                  />
                </td>
                <td>{show.title}</td>
                <td>{show.genre}</td>
                <td>{show.status}</td>
                <td>
                  {show.watchedEpisodes}/{show.totalEpisodes}
                </td>
                <td>{show.rating || "-"}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      {/* Edit Form */}
      {editShow && (
        <form onSubmit={handleUpdate} style={{ marginTop: "20px" }}>
          <h3>Edit TV Show</h3>

          <div>
            <label>Title:</label><br />
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
            />
            {errors.title && <p style={{ color: "red" }}>{errors.title}</p>}
          </div>

          <div>
            <label>Genre:</label><br />
            <input
              type="text"
              name="genre"
              value={formData.genre}
              onChange={handleChange}
            />
            {errors.genre && <p style={{ color: "red" }}>{errors.genre}</p>}
          </div>

          <div>
            <label>Status:</label><br />
            <select
              name="status"
              value={formData.status}
              onChange={handleChange}
            >
              <option value="Ongoing">Ongoing</option>
              <option value="Completed">Completed</option>
            </select>
          </div>

          <div>
            <label>Watched Episodes:</label><br />
            <input
              type="number"
              name="watchedEpisodes"
              value={formData.watchedEpisodes}
              onChange={handleChange}
            />
          </div>

          <div>
            <label>Total Episodes:</label><br />
            <input
              type="number"
              name="totalEpisodes"
              value={formData.totalEpisodes}
              onChange={handleChange}
            />
            {errors.totalEpisodes && (
              <p style={{ color: "red" }}>{errors.totalEpisodes}</p>
            )}
          </div>

          <div>
            <label>Rating (1–10, optional):</label><br />
            <input
              type="number"
              name="rating"
              value={formData.rating}
              onChange={handleChange}
            />
          </div>

          {errors.api && <p style={{ color: "red" }}>{errors.api}</p>}

          <button type="submit">💾 Save Changes</button>
        </form>
      )}
    </div>
  );
}

export default ManageTVShow;
