import React, { useEffect, useState } from 'react';
import axios from 'axios';

function ManageTVShow() {
  // ----------------------------
  // 1️⃣ State Variables
  // ----------------------------
  const [tvShows, setTvShows] = useState([]);       // stores all TV shows
  const [filterStatus, setFilterStatus] = useState('All Statuses'); // dropdown filter
  const [error, setError] = useState('');           // for API or other errors

  // ----------------------------
  // 2️⃣ Fetch TV Shows on Page Load
  // ----------------------------
  useEffect(() => {
    const fetchTVShows = async () => {
      try {
        const response = await axios.get('http://localhost:4000/api/tvshows');
        setTvShows(response.data); // assume API returns [{ title, genre, ... }]
      } catch (err) {
        setError('Failed to fetch TV shows. Please try again later.');
      }
    };

    fetchTVShows();
  }, []);

  // ----------------------------
  // 3️⃣ Handle Filter Change
  // ----------------------------
  const handleFilterChange = (e) => {
    setFilterStatus(e.target.value);
  };

  // ----------------------------
  // 4️⃣ Filtered List for Display
  // ----------------------------
  const filteredShows = tvShows.filter((show) => {
    if (filterStatus === 'All Statuses') return true;
    return show.status === filterStatus;
  });

  // ----------------------------
  // 5️⃣ Render UI
  // ----------------------------
  return (
    <div style={{ padding: '20px' }}>
      <h2>📺 Manage TV Shows</h2>

      // Buttons 
      <div style={{ marginBottom: '15px' }}>
        <button style={{ marginRight: '10px' }}>➕ Add TV Show</button>
        <button>🚪 Logout</button>
      </div>

      

      // Table 
      // Dropdown Filter 
      <div style={{ marginBottom: '15px' }}>
        <label>Filter by Status: </label>
        <select value={filterStatus} onChange={handleFilterChange}>
          <option>All Statuses</option>
          <option>Ongoing</option>
          <option>Completed</option>
        </select>
      </div>

      // Error Message 
      {error && <p style={{ color: 'red' }}>{error}</p>}

      <table border="1" cellPadding="8" style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead style={{ backgroundColor: '#f2f2f2' }}>
          <tr>
            <th>Title</th>
            <th>Genre</th>
            <th>Status</th>
            <th>Progress</th>
            <th>Rating</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredShows.length === 0 ? (
            <tr>
              <td colSpan="6" style={{ textAlign: 'center' }}>
                No TV shows found
              </td>
            </tr>
          ) : (
            filteredShows.map((show, index) => (
              <tr key={index}>
                <td>{show.title}</td>
                <td>{show.genre}</td>
                <td>{show.status}</td>
                <td>
                  {show.watchedEpisodes}/{show.totalEpisodes}
                </td>
                <td>{show.rating || '-'}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default ManageTVShow;