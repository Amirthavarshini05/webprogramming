import React, { useState } from 'react';
import axios from 'axios';

const CreateTVShow = () => {
  // State for form data
  const [formData, setFormData] = useState({
    title: '',
    genre: '',
    status: 'Ongoing',
    totalEpisodes: '',
    watchedEpisodes: '',
    rating: ''
  });

  // State for validation or API errors
  const [errors, setErrors] = useState({});

  // Update form values when user types
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Basic validation
    const newErrors = {};
    if (!formData.title.trim()) newErrors.title = 'Title is required';
    if (!formData.genre.trim()) newErrors.genre = 'Genre is required';
    if (!formData.totalEpisodes || formData.totalEpisodes < 1)
      newErrors.totalEpisodes = 'Total episodes must be at least 1';
    setErrors(newErrors);

    // Stop if validation failed
    if (Object.keys(newErrors).length > 0) return;

    try {
      // Send data to backend API
      const response = await axios.post('http://localhost:4000/api/tvshows', formData);

      alert('TV Show added successfully!');
      //console.log('Server response:', response.data);

      // Clear form after success
      setFormData({
        title: '',
        genre: '',
        status: 'Ongoing',
        totalEpisodes: '',
        watchedEpisodes: '',
        rating: ''
      });
      setErrors({});

    } catch (err) {
      setErrors({ api: 'Failed to add show. Try again later.' });
    }
  };

  return (
    <div>
      <h2>Add TV Show</h2>

      <form onSubmit={handleSubmit}>
        
        <div>
          <label htmlFor="title">Title:</label><br />
          <input
            id="title"
            type="text"
            name="title"
            placeholder="Enter show title"
            value={formData.title}
            onChange={handleChange}
          />
          {errors.title && <p style={{ color: 'red' }}>{errors.title}</p>}
        </div>

        <div>
          <label htmlFor="genre">Genre:</label><br />
          <input
            id="genre"
            type="text"
            name="genre"
            placeholder="Enter genre"
            value={formData.genre}
            onChange={handleChange}
          />
          {errors.genre && <p style={{ color: 'red' }}>{errors.genre}</p>}
        </div>

        <div>
          <label htmlFor="status">Status:</label><br />
          <select
            id="status"
            name="status"
            value={formData.status}
            onChange={handleChange}
            defaultValue="Ongoing"
          >
            <option value="Ongoing">Ongoing</option>
            <option value="Completed">Completed</option>
          </select>
        </div>

        <div>
          <label htmlFor="totalEpisodes">Total Episodes:</label><br />
          <input
            id="totalEpisodes"
            type="number"
            name="totalEpisodes"
            placeholder="Enter total episodes"
            value={formData.totalEpisodes}
            onChange={handleChange}
          />
          {errors.totalEpisodes && <p style={{ color: 'red' }}>{errors.totalEpisodes}</p>}
        </div>

        <div>
          <label htmlFor="watchedEpisodes">Watched Episodes:</label><br />
          <input
            id="watchedEpisodes"
            type="number"
            name="watchedEpisodes"
            placeholder="Enter watched episodes"
            value={formData.watchedEpisodes}
            onChange={handleChange}
          />
        </div>

        <div>
          <label htmlFor="rating">Rating (1–10, optional):</label><br />
          <input
            id="rating"
            type="number"
            name="rating"
            placeholder="Enter rating"
            min="1"
            max="10"
            value={formData.rating}
            onChange={handleChange}
          />
        </div>
        {/* API error display */}
        {errors.api && <p style={{ color: 'red' }}>{errors.api}</p>}
        <div>
          <button type="submit">Add TV Show</button>
        </div>
      </form>
    </div>
  );
}

export default CreateTVShow;
