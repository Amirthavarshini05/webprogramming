import React from 'react';

function ManageTVShow() {
  const tvShows = [];

  return (
    <div>
      <h2>Manage TV Shows</h2>

      <button>Add TV Show</button>
      <button>Logout</button>

      <select defaultValue="All Statuses">
        <option>All Statuses</option>
        <option>Ongoing</option>
        <option>Completed</option>
      </select>

      <table>
        <thead>
          <tr>
            <th>Title</th>
            <th>Genre</th>
            <th>Status</th>
            <th>Progress</th>
            <th>Rating</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {tvShows.length === 0 ? (
            <tr>
              <td colSpan="6">No TV shows found</td>
            </tr>
          ) : (
            tvShows.map((show, index) => (
              <tr key={index}>
                <td>{show.title}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default ManageTVShow;

