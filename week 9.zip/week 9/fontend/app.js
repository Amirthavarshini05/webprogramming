/*
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Register from './Register';
import Login from './Login'; // import here (only once for the route)
import ErrorPage from './ErrorPage'; // ✅ import


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<ErrorPage />} />
      </Routes>
    </Router>
  );
}

export default App;

*/










import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Login from './Components/Login';
import Register from './Components/Register';
import ManageTVShow from './Admin/ManageTVShow';
import CreateTVShow from './Admin/CreateTVShow';
import DisplayTVShows from './Viewers/DisplayTVShows';
import ErrorPage from './Components/ErrorPage';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/managetvshow" element={<ManageTVShow />} />
      <Route path="/createtvshow" element={<CreateTVShow />} />
      <Route path="/displaytvshows" element={<DisplayTVShows />} />
      <Route path="*" element={<ErrorPage />} />
    </Routes>
  );
}

export default App;
