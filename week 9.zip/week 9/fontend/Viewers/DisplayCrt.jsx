import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function DisplayTVShows() {
  const [tvShows, setTvShows] = useState([]);
  const [sortOption, setSortOption] = useState("Sort by Title (A-Z)");
  const navigate = useNavigate();

  // ✅ Fetch all TV shows when the component loads
  useEffect(() => {
    fetchTVShows();
  }, []);

  const fetchTVShows = async () => {
    try {
      const response = await axios.get("http://localhost:4000/api/tvshows");
      setTvShows(response.data);
    } catch (error) {
      console.error("Error fetching TV shows:", error);
    }
  };

  // ✅ Sorting logic
  const sortShows = (option, shows) => {
    switch (option) {
      case "Sort by Title (A-Z)":
        return [...shows].sort((a, b) => a.title.localeCompare(b.title));
      case "Sort by Title (Z-A)":
        return [...shows].sort((a, b) => b.title.localeCompare(a.title));
      case "Sort by Rating (High-Low)":
        return [...shows].sort((a, b) => b.rating - a.rating);
      case "Sort by Rating (Low-High)":
        return [...shows].sort((a, b) => a.rating - b.rating);
      default:
        return shows;
    }
  };

  const handleSortChange = (e) => {
    setSortOption(e.target.value);
  };

  

  // ✅ Apply sorting before rendering
  const sortedShows = sortShows(sortOption, tvShows);

  return (
    <div>
      <h2>TV Show Catalog</h2>

      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "1rem" }}>

        <select value={sortOption} onChange={handleSortChange}>
          <option>Sort by Title (A-Z)</option>
          <option>Sort by Title (Z-A)</option>
          <option>Sort by Rating (High-Low)</option>
          <option>Sort by Rating (Low-High)</option>
        </select>
      </div>

      <table border="1" width="100%">
        <thead>
          <tr>
            <th>Title</th>
            <th>Genre</th>
            <th>Status</th>
            <th>Progress</th>
            <th>Rating</th>
          </tr>
        </thead>
        <tbody>
          {sortedShows.length === 0 ? (
            <tr>
              <td colSpan="5" style={{ textAlign: "center" }}>
                No TV shows found
              </td>
            </tr>
          ) : (
            sortedShows.map((show) => (
              <tr key={show._id}>
                <td>{show.title}</td>
                <td>{show.genre}</td>
                <td>{show.status}</td>
                <td>
                  {show.watchedEpisodes}/{show.totalEpisodes}
                </td>
                <td>{show.rating}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default DisplayTVShows;
