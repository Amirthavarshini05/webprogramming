import React from 'react';

function DisplayTVShows() {
  const tvShows = [];

  return (
    <div>
      <h2>TV Show Catalog</h2>

      <button>Logout</button>
      <select defaultValue="Sort by Title (A-Z)">
        <option>Sort by Title (A-Z)</option>
        <option>Sort by Title (Z-A)</option>
      </select>

      <table>
        <thead>
          <tr>
            <th>Title</th>
            <th>Genre</th>
            <th>Status</th>
            <th>Progress</th>
            <th>Rating</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {tvShows.length === 0 ? (
            <tr>
              <td colSpan="6">No TV shows found</td>
            </tr>
          ) : (
            tvShows.map((show, index) => (
              <tr key={index}>
                <td>{show.title}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default DisplayTVShows;
