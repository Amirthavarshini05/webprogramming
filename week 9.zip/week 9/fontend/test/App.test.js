import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import Login from '../Components/Login';
import '@testing-library/jest-dom/extend-expect';
import axios from 'axios';
import Register from '../Components/Register';
import ErrorPage from '../Components/ErrorPage';
import DisplayTVShows from '../Viewers/DisplayTVShows';
import ManageTVShow from '../Admin/ManageTVShow';
import CreateTVShow from '../Admin/CreateTVShow';

 
jest.mock('axios');
 
describe('Login Component', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });
 
  const renderLoginComponent = () => {
    return render(
      <Router>
        <Login />
      </Router>
    );
  };
 
 
  test('frontend_login_component_renders_the_with_login_heading', () => {
    renderLoginComponent();
 
 
    const loginHeadings = screen.getAllByText(/Login/i);
    expect(loginHeadings.length).toBeGreaterThan(0);
 
  });
 
 
  test('frontend_login_component_displays_validation_messages_when_login_button_is_clicked_with_empty_fields', async () => {
    renderLoginComponent();
 
    fireEvent.click(screen.getByRole('button', { name: /Login/i }));
 
    expect(await screen.findByText('Email is required')).toBeInTheDocument();
    expect(await screen.findByText('Password is required')).toBeInTheDocument();
  });
   
});
 

describe('Register Component', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  const renderRegisterComponent = () => {
    return render(
      <Router>
        <Register />
      </Router>
    );
  };

  test('frontend_register_component_renders_with_create_account_heading', () => {
    renderRegisterComponent();

    const createAccountHeading = screen.getByText('Register for SavorStudio');
    expect(createAccountHeading).toBeInTheDocument();
  });

  test('frontend_register_component_displays_validation_messages_when_register_button_is_clicked_with_empty_fields', () => {
    renderRegisterComponent();

    fireEvent.click(screen.getByRole('button', { name: /Register/i }));

    expect(screen.getByText('First Name is required')).toBeInTheDocument();
    expect(screen.getByText('Last Name is required')).toBeInTheDocument();
    expect(screen.getByText('Mobile Number is required')).toBeInTheDocument();
    expect(screen.getByText('Please enter a valid email address')).toBeInTheDocument();
    expect(screen.getByText('Password must be at least 6 characters')).toBeInTheDocument();
    expect(screen.getByText('Confirm Password is required')).toBeInTheDocument();
  });
});
 
describe('ErrorPage Component', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });
  const renderErrorComponent = () => {
    return render(
      <Router>
        <ErrorPage />
      </Router>
    );
  };
  test('frontend_errorpage_component_renders_with_error_heading', () => {
    renderErrorComponent();
    const headingElement = screen.getByText(/Something Went Wrong/i);
    expect(headingElement).toBeInTheDocument();
  });
 
  test('frontend_errorpage_component_renders_with_error_content', () => {
    renderErrorComponent();
    const paragraphElement = screen.getByText(/We're sorry, but an error occurred. Please try again later./i);
    expect(paragraphElement).toBeInTheDocument();
  });
});


describe('DisplayTVShows Component', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  const renderDisplayTVShowsComponent = () => {
    return render(
      <Router>
        <DisplayTVShows />
      </Router>
    );
  };

  test('frontend_displaytvshows_component_renders_with_tvshow_catalog_heading', () => {
    renderDisplayTVShowsComponent();

    const headingElement = screen.getByRole('heading', { name: 'TV Show Catalog' });
    expect(headingElement).toBeInTheDocument();
  });

  test('frontend_displaytvshows_component_renders_logout_button', () => {
    renderDisplayTVShowsComponent();

    const logoutButton = screen.getByRole('button', { name: /Logout/i });
    expect(logoutButton).toBeInTheDocument();
  });

  test('frontend_displaytvshows_component_renders_sort_dropdown', () => {
    renderDisplayTVShowsComponent();

    const sortDropdown = screen.getByDisplayValue('Sort by Title (A-Z)');
    expect(sortDropdown).toBeInTheDocument();
  });

  test('frontend_displaytvshows_component_renders_table_headers', () => {
    renderDisplayTVShowsComponent();

    expect(screen.getByText('Title')).toBeInTheDocument();
    expect(screen.getByText('Genre')).toBeInTheDocument();
    expect(screen.getByText('Status')).toBeInTheDocument();
    expect(screen.getByText('Progress')).toBeInTheDocument();
    expect(screen.getByText('Rating')).toBeInTheDocument();
    expect(screen.getByText('Action')).toBeInTheDocument();
  });

  test('frontend_displaytvshows_component_shows_no_tvshows_message_when_empty', () => {
    renderDisplayTVShowsComponent();

    const noRecordsMessage = screen.getByText('No TV shows found');
    expect(noRecordsMessage).toBeInTheDocument();
  });
});

describe('ManageTVShow Component', () => {
  beforeEach(() => {
    // Mock localStorage
    const localStorageMock = {
      getItem: jest.fn((key) => {
        if (key === 'editId') return '';
        if (key === 'token') return 'mock-token';
        if (key === 'userData') return JSON.stringify({ userId: 'mock-user-id' });
        return null;
      }),
      setItem: jest.fn(),
    };
    Object.defineProperty(window, 'localStorage', {
      value: localStorageMock,
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  const renderManageTVShowComponent = () => {
    return render(
      <Router>
        <ManageTVShow />
      </Router>
    );
  };

  test('frontend_managetvshow_component_renders_with_manage_tvshows_heading', () => {
    renderManageTVShowComponent();

    const headingElement = screen.getByRole('heading', { name: 'Manage TV Shows' });
    expect(headingElement).toBeInTheDocument();
  });

  test('frontend_managetvshow_component_renders_navigation_buttons', () => {
    renderManageTVShowComponent();

    const addTVShowButton = screen.getByRole('button', { name: /Add TV Show/i });
    const logoutButton = screen.getByRole('button', { name: /Logout/i });
        
    expect(addTVShowButton).toBeInTheDocument();
    expect(logoutButton).toBeInTheDocument();
  });

  test('frontend_managetvshow_component_renders_status_filter_dropdown', () => {
    renderManageTVShowComponent();

    const statusFilter = screen.getByDisplayValue('All Statuses');
    expect(statusFilter).toBeInTheDocument();
  });

  test('frontend_managetvshow_component_renders_table_headers', () => {
    renderManageTVShowComponent();

    expect(screen.getByText('Title')).toBeInTheDocument();
    expect(screen.getByText('Genre')).toBeInTheDocument();
    expect(screen.getByText('Status')).toBeInTheDocument();
    expect(screen.getByText('Progress')).toBeInTheDocument();
    expect(screen.getByText('Rating')).toBeInTheDocument();
    expect(screen.getByText('Actions')).toBeInTheDocument();
  });

  test('frontend_managetvshow_component_shows_no_tvshows_message_when_empty', () => {
    renderManageTVShowComponent();

    const noRecordsMessage = screen.getByText('No TV shows found');
    expect(noRecordsMessage).toBeInTheDocument();
  });
});

describe('CreateTVShow Component', () => {
  beforeEach(() => {
    // Mock localStorage
    const localStorageMock = {
      getItem: jest.fn((key) => {
        if (key === 'editId') return '';
        if (key === 'token') return 'mock-token';
        if (key === 'userData') return JSON.stringify({ userId: 'mock-user-id' });
        return null;
      }),
      setItem: jest.fn(),
    };
    Object.defineProperty(window, 'localStorage', {
      value: localStorageMock,
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  const renderCreateTVShowComponent = (props = {}) => {
    return render(
      <Router>
        <CreateTVShow {...props} />
      </Router>
    );
  };

  test('frontend_createtvshow_component_renders_with_add_tvshow_heading', () => {
    renderCreateTVShowComponent();

    const headingElement = screen.getByRole('heading', { name: 'Add TV Show' });
    expect(headingElement).toBeInTheDocument();
  });

  test('frontend_createtvshow_component_renders_all_form_fields', () => {
    renderCreateTVShowComponent();

    // Check for form labels
    expect(screen.getByText('Title:')).toBeInTheDocument();
    expect(screen.getByText('Genre:')).toBeInTheDocument();
    expect(screen.getByText('Status:')).toBeInTheDocument();
    expect(screen.getByText('Total Episodes:')).toBeInTheDocument();
    expect(screen.getByText('Watched Episodes:')).toBeInTheDocument();
    expect(screen.getByText('Rating (1-10, optional):')).toBeInTheDocument();
  });

  test('frontend_createtvshow_component_renders_submit_button', () => {
    renderCreateTVShowComponent();

    const submitButton = screen.getByRole('button', { name: /Add TV Show/i });
    expect(submitButton).toBeInTheDocument();
  });

  test('frontend_createtvshow_component_displays_validation_errors_on_empty_submit', () => {
    renderCreateTVShowComponent();

    const submitButton = screen.getByRole('button', { name: /Add TV Show|Update TV Show/i });
    fireEvent.click(submitButton);

    expect(screen.getByText('Title is required')).toBeInTheDocument();
    expect(screen.getByText('Genre is required')).toBeInTheDocument();
    expect(screen.getByText('Total episodes must be at least 1')).toBeInTheDocument();
  });
});