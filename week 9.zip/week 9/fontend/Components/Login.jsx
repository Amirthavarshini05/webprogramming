import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login = () => {
const navigate = useNavigate();

const [formData, setFormData] = useState({
email: '',
password: ''
});

const [errors, setErrors] = useState({});

const handleChange = (e) => {
setFormData({
...formData,
[e.target.name]: e.target.value
});
};

const handleSubmit = async (e) => {
e.preventDefault();
const newErrors = {};
if (!formData.email) newErrors.email = 'Email is required';
if (!formData.password) newErrors.password = 'Password is required';
setErrors(newErrors);

if (Object.keys(newErrors).length > 0) return;

try {
const response = await axios.post('http://localhost:4000/api/login', formData);
localStorage.setItem('token', response.data.token);
navigate('/dashboard');
} catch (err) {
setErrors({ api: 'Invalid email or password' });
}
};

return (
<div className="login-container">
<h2>Login</h2>

<form onSubmit={handleSubmit}>
<div>
<label htmlFor="email">Email:</label><br />
<input
type="email"
name="email"
value={formData.email}
onChange={handleChange}
placeholder="Enter email"
/>
{errors.email && <p style={{ color: 'red' }}>{errors.email}</p>}
</div>

<div>
<label htmlFor="password">Password:</label><br />
<input
type="password"
name="password"
value={formData.password}
onChange={handleChange}
placeholder="Enter password"
/>
{errors.password && <p style={{ color: 'red' }}>{errors.password}</p>}
</div>

{errors.api && <p style={{ color: 'red' }}>{errors.api}</p>}
<div>
  <button type="submit">Login</button>
</div>
</form>
</div>
);
};

export default Login;