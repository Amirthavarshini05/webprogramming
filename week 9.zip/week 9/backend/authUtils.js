const jwt = require('jsonwebtoken');
const SECRET_KEY = 'mysecretkey';

exports.validateToken = (req, res, next) => {
  try {
    const token = req.header('Authorization');
    if (!token) {
      return res.status(400).json({ message: 'Authentication failed' });
    }
    jwt.verify(token, SECRET_KEY, (err, decoded) => {
      if (err) {
        return res.status(400).json({ message: 'Authentication failed' });
      }
      req.user = decoded;
      next();
    });
  } catch {
    res.status(400).json({ message: 'Authentication failed' });
  }
};
