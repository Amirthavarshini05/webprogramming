const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

// ➤ Add User (CREATE)
router.post('/addUser', userController.addUser);

// ➤ Get all Users (READ)
router.get('/getAllUsers', userController.getAllUsers);

// ➤ Get user by credentials (READ)
router.post('/getUserByUsernameAndPassword', userController.getUserByUsernameAndPassword);

module.exports = router;
