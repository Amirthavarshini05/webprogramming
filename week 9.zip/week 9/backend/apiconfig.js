const API_BASE_URL = 'http://localhost:4000/api';

export default API_BASE_URL;