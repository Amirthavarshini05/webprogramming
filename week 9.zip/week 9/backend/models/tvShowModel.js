const mongoose = require('mongoose');

const tvShowSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Title is required'],
    maxlength: [150, 'Title exceeds maximum length']
  },
  genre: {
    type: String,
    enum: ['Drama', 'Comedy', 'Action', 'Sci-Fi', 'Thriller', 'Horror', 'Romance'],
    required: [true, 'Genre is required']
  },
  status: {
    type: String,
    enum: ['Completed', 'Currently Watching', 'Dropped', 'Plan to Watch'],
    required: [true, 'Status is required']
  },
  totalEpisodes: {
    type: Number,
    required: [true, 'Total episodes are required'],
    min: [0, 'Total episodes cannot be negative']
  },
  watchedEpisodes: {
    type: Number,
    required: [true, 'Watched episodes are required'],
    min: [0, 'Watched episodes cannot be negative']
  },
  rating: {
    type: Number,
    required: [true, 'Rating is required'],
    min: [0, 'Rating cannot be below 0'],
    max: [10, 'Rating cannot exceed 10']
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    required: [true, 'User ID is required'],
    ref: 'User'
  }
});

module.exports = mongoose.model('TVShow', tvShowSchema);
