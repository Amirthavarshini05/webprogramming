const userController = require('../controllers/userController');
const User = require('../models/userModel');
const mongoose = require('mongoose');
const { validateToken } = require('../authUtils');
const TVShow = require('../models/tvShowModel');
const {
  getAllTVShows,
  getTVShowById,
  getTVShowsByUserId,
  addTVShow,
  updateTVShow,
  deleteTVShow

} = require('../controllers/tvShowController');


// TV Show Controller Tests
describe('getAllTVShows_Controller', () => {
  test('backend_getalltvshows_should_return_tvshows_with_a_200_status_code', async () => {
    // Sample TV shows data
    const tvShowsData = [
      {
        title: 'Breaking Bad',
        genre: 'Drama',
        status: 'Completed',
        totalEpisodes: 62,
        watchedEpisodes: 62,
        rating: 10,
        userId: new mongoose.Types.ObjectId()
      },
      {
        title: 'The Office',
        genre: 'Comedy',
        status: 'Currently Watching',
        totalEpisodes: 188,
        watchedEpisodes: 45,
        rating: 8,
        userId: new mongoose.Types.ObjectId()
      }
    ];

    const req = {
      body: { sortOrder: 1 }
    };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn()
    };

    TVShow.find = jest.fn().mockReturnValue({
      sort: jest.fn().mockResolvedValue(tvShowsData)
    });

    await getAllTVShows(req, res);

    expect(res.status).toHaveBeenCalledWith(200);
  });

  test('backend_getalltvshows_should_handle_errors_and_respond_with_a_500_status_code_and_an_error_message', async () => {
    const error = new Error('Database error');

    const req = {
      body: { sortOrder: -1 }
    };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn()
    };

    TVShow.find = jest.fn().mockReturnValue({
      sort: jest.fn().mockRejectedValue(error)
    });

    await getAllTVShows(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });
});

describe('addTVShow_Controller', () => {
  test('backend_addtvshow_should_add_a_tvshow_and_respond_with_a_200_status_code_and_success_message', async () => {
    // Sample TV show data to be added
    const tvShowToAdd = {
      title: 'Stranger Things',
      genre: 'Sci-Fi',
      status: 'Plan to Watch',
      totalEpisodes: 42,
      watchedEpisodes: 0,
      rating: 9,
      userId: new mongoose.Types.ObjectId()
    };

    // Mock the TVShow.create method to resolve successfully
    TVShow.create = jest.fn().mockResolvedValue(tvShowToAdd);

    // Mock Express request and response objects
    const req = { body: tvShowToAdd };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn()
    };

    // Call the controller function
    await addTVShow(req, res);

    // Assertions
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith({ message: 'TV Show Added Successfully' });
  });

  test('backend_addtvshow_should_handle_errors_and_respond_with_a_500_status_code_and_an_error_message', async () => {
    const error = new Error('Database error');

    TVShow.create = jest.fn().mockRejectedValue(error);

    const req = { body: {} };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn()
    };

    await addTVShow(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({ message: 'Database error' });
  });
});

describe('updateTVShow_Controller', () => {
  test('backend_updatetvshow_should_update_tvshow_and_respond_with_a_200_status_code_and_success_message', async () => {
    const tvShowId = new mongoose.Types.ObjectId();
    const updatedTVShowData = {
      title: 'Updated Stranger Things',
      genre: 'Horror',
      status: 'Currently Watching',
      totalEpisodes: 42,
      watchedEpisodes: 25,
      rating: 9,
      userId: new mongoose.Types.ObjectId()
    };

    const req = { params: { id: tvShowId }, body: updatedTVShowData };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    TVShow.findByIdAndUpdate = jest.fn().mockResolvedValue(updatedTVShowData);

    await updateTVShow(req, res);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith({ message: 'TV Show Updated Successfully' });
  });

  test('backend_updatetvshow_should_handle_not_finding_a_tvshow_and_respond_with_a_404_status_code', async () => {
    const req = { params: { id: new mongoose.Types.ObjectId() }, body: {} };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    TVShow.findByIdAndUpdate = jest.fn().mockResolvedValue(null);

    await updateTVShow(req, res);

    expect(TVShow.findByIdAndUpdate).toHaveBeenCalledWith(req.params.id, {}, { new: true });
    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith({ message: 'TV show not found' });
  });

  test('backend_updatetvshow_should_handle_errors_and_respond_with_a_500_status_code_and_an_error_message', async () => {
    const error = new Error('Database error');
    const req = { params: { id: new mongoose.Types.ObjectId() }, body: {} };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    TVShow.findByIdAndUpdate = jest.fn().mockRejectedValue(error);

    await updateTVShow(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({ message: 'Database error' });
  });
});

describe('deleteTVShow_Controller', () => {
  test('backend_deletetvshow_should_delete_tvshow_and_respond_with_a_200_status_code_and_success_message', async () => {
    const tvShowId = new mongoose.Types.ObjectId();
    const req = { params: { id: tvShowId } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    TVShow.findByIdAndDelete = jest.fn().mockResolvedValue({
      _id: tvShowId,
      title: 'Sample TV Show',
      genre: 'Action',
      status: 'Completed',
      totalEpisodes: 20,
      watchedEpisodes: 20,
      userId: new mongoose.Types.ObjectId()
    });

    await deleteTVShow(req, res);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith({ message: 'TV Show Deleted Successfully' });
  });

  test('backend_deletetvshow_should_handle_not_finding_a_tvshow_and_respond_with_a_404_status_code', async () => {
    const req = { params: { id: new mongoose.Types.ObjectId() } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    TVShow.findByIdAndDelete = jest.fn().mockResolvedValue(null);

    await deleteTVShow(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith({ message: 'TV show not found' });
  });

  test('backend_deletetvshow_should_handle_errors_and_respond_with_a_500_status_code_and_an_error_message', async () => {
    const error = new Error('Database error');
    const req = { params: { id: new mongoose.Types.ObjectId() } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    TVShow.findByIdAndDelete = jest.fn().mockRejectedValue(error);

    await deleteTVShow(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({ message: 'Database error' });
  });
});

describe('getTVShowById_Controller', () => {
  test('backend_gettvshowbyid_should_return_a_tvshow_with_a_200_status_code', async () => {
    const tvShowId = new mongoose.Types.ObjectId();
    const tvShowData = {
      _id: tvShowId,
      title: 'Game of Thrones',
      genre: 'Drama',
      status: 'Dropped',
      totalEpisodes: 73,
      watchedEpisodes: 60,
      rating: 7,
      userId: new mongoose.Types.ObjectId()
    };

    TVShow.findById = jest.fn().mockResolvedValue(tvShowData);

    const req = { params: { id: tvShowId } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn()
    };

    await getTVShowById(req, res);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(tvShowData);
  });

  test('backend_gettvshowbyid_should_return_not_found_with_a_404_status_code', async () => {
    const req = { params: { id: new mongoose.Types.ObjectId() } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn()
    };

    TVShow.findById = jest.fn().mockResolvedValue(null);

    await getTVShowById(req, res);

    expect(TVShow.findById).toHaveBeenCalledWith(req.params.id);
    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith({ message: 'TV show not found' });
  });

  test('backend_gettvshowbyid_should_handle_errors_and_respond_with_a_500_status_code_and_an_error_message', async () => {
    const error = new Error('Database error');
    const req = { params: { id: new mongoose.Types.ObjectId() } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn()
    };

    TVShow.findById = jest.fn().mockRejectedValue(error);

    await getTVShowById(req, res);

    expect(TVShow.findById).toHaveBeenCalledWith(req.params.id);
    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({ message: 'Database error' });
  });
});

describe('getTVShowsByUserId_Controller', () => {
  test('backend_gettvshowsbyuserid_should_return_tvshows_for_a_valid_userid_with_a_200_status_code', async () => {
    const userId = new mongoose.Types.ObjectId();
    const tvShowsData = [
      {
        _id: new mongoose.Types.ObjectId(),
        title: 'Friends',
        genre: 'Comedy',
        status: 'Completed',
        totalEpisodes: 236,
        watchedEpisodes: 236,
        rating: 9,
        userId
      },
      {
        _id: new mongoose.Types.ObjectId(),
        title: 'The Big Bang Theory',
        genre: 'Comedy',
        status: 'Completed',
        totalEpisodes: 279,
        watchedEpisodes: 279,
        rating: 8,
        userId
      }
    ];

    const req = { body: { userId, status: 'Completed' } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn()
    };

    TVShow.find = jest.fn().mockResolvedValue(tvShowsData);

    await getTVShowsByUserId(req, res);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(tvShowsData);
  });

  test('backend_gettvshowsbyuserid_should_handle_errors_and_respond_with_a_500_status_code_and_an_error_message', async () => {
    const error = new Error('Database error');
    const req = { body: { userId: new mongoose.Types.ObjectId(), status: 'Currently Watching' } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn()
    };

    TVShow.find = jest.fn().mockRejectedValue(error);

    await getTVShowsByUserId(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({ message: 'Database error' });
  });
});

describe('TVShow_Model_Validation', () => {
    // 1.TV Model Tests
  test('backend_tvshow_should_be_valid_with_correct_data', async () => {
    const validTVShowData = {
      title: 'Better Call Saul',
      genre: 'Drama',
      status: 'Completed',
      totalEpisodes: 63,
      watchedEpisodes: 63,
      rating: 9,
      userId: new mongoose.Types.ObjectId()
    };

    const tvShow = new TVShow(validTVShowData);
    await expect(tvShow.validate()).resolves.toBeUndefined();
  });

  // 2.TV Model Tests
  test('backend_tvshow_should_throw_validation_error_without_required_fields', async () => {
    const invalidTVShowData = {};

    const tvShow = new TVShow(invalidTVShowData);
    await expect(tvShow.validate()).rejects.toThrow();
  });

  // 3.TV Model Tests
  test('backend_tvshow_should_throw_validation_error_with_invalid_enum_values', async () => {
    const invalidTVShowData = {
      title: 'Invalid TV Show',
      genre: 'Invalid Genre', // Invalid
      status: 'Invalid Status', // Invalid
      totalEpisodes: 10,
      watchedEpisodes: 5,
      rating: 8,
      userId: new mongoose.Types.ObjectId()
    };

    const tvShow = new TVShow(invalidTVShowData);
    await expect(tvShow.validate()).rejects.toThrow();
  });

// 4.TV Model Tests
  test('backend_tvshow_should_throw_validation_error_with_negative_watched_episodes', async () => {
    const invalidTVShowData = {
      title: 'Another Faulty TV Show',
      genre: 'Comedy',
      status: 'Currently Watching',
      totalEpisodes: 20,
      watchedEpisodes: -5, // Invalid
      rating: 6,
      userId: new mongoose.Types.ObjectId()
    };

    const tvShow = new TVShow(invalidTVShowData);
    await expect(tvShow.validate()).rejects.toThrow();
  });
// 5.TV Model Tests
  test('backend_tvshow_should_throw_validation_error_with_invalid_rating_range', async () => {
    const invalidTVShowData = {
      title: 'Rating Test TV Show',
      genre: 'Thriller',
      status: 'Completed',
      totalEpisodes: 15,
      watchedEpisodes: 15,
      rating: 11, // Invalid - exceeds max
      userId: new mongoose.Types.ObjectId()
    };

    const tvShow = new TVShow(invalidTVShowData);
    await expect(tvShow.validate()).rejects.toThrow();
  });

  // 6.TV Model Tests
  test('backend_tvshow_should_throw_validation_error_with_title_exceeding_maxlength', async () => {
    const invalidTVShowData = {
      title: 'This is a very long title that exceeds the maximum character limit of 150 characters and should fail validation because it is way too long for a TV show title', // Exceeds 150 characters
      genre: 'Drama',
      status: 'Plan to Watch',
      totalEpisodes: 10,
      watchedEpisodes: 0,
      rating: 8,
      userId: new mongoose.Types.ObjectId()
    };

    const tvShow = new TVShow(invalidTVShowData);
    await expect(tvShow.validate()).rejects.toThrow();
  });

});


describe('getUserByUsernameAndPassword', () => {
  // 1.User Controller Tests
  test('backend_getuserbyusernameandpassword_should_return_invalid_credentials_with_a_200_status_code', async () => {
    // Sample user credentials
    const userCredentials = {
      email: 'nonexistent@example.com',
      password: 'incorrect_password',
    };

    // Mock Express request and response objects
    const req = {
      body: userCredentials,
    };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    // Mock the User.findOne method to resolve with null (user not found)
    User.findOne = jest.fn().mockResolvedValue(null);

    // Call the controller function
    await userController.getUserByUsernameAndPassword(req, res);

    // Assertions
    expect(User.findOne).toHaveBeenCalledWith(userCredentials);
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith({ message: 'Invalid Credentials' });
  });

    // 2.User Controller Tests
  test('backend_getuserbyusernameandpassword_should_handle_errors_and_respond_with_a_500_status_code_and_an_error_message', async () => {
    // Mock an error to be thrown when calling User.findOne
    const error = new Error('Database error');

    // Sample user credentials
    const userCredentials = {
      email: 'john@example.com',
      password: 'password123',
    };

    // Mock Express request and response objects
    const req = {
      body: userCredentials,
    };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    // Mock the User.findOne method to reject with an error
    User.findOne = jest.fn().mockRejectedValue(error);

    // Call the controller function
    await userController.getUserByUsernameAndPassword(req, res);

    // Assertions
    expect(User.findOne).toHaveBeenCalledWith(userCredentials);
    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({ message: 'Database error' });
  });
});

describe('addUser', () => {
    // 3.User Controller Tests
  test('backend_adduser_should_add_user_and_respond_with_a_200_status_code_and_success_message', async () => {
    // Sample user data
    const userData = {
      username: 'john_doe',
      email: 'john@example.com',
      password: 'password123',
    };

    // Mock Express request and response objects
    const req = {
      body: userData,
    };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    // Mock the User.create method to resolve with the sample user data
    User.create = jest.fn().mockResolvedValue(userData);

    // Call the controller function
    await userController.addUser(req, res);

    // Assertions
    expect(User.create).toHaveBeenCalledWith(userData);
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith({ message: 'Success' });
  });

    // 4.User Controller Tests
  test('backend_adduser_should_handle_errors_and_respond_with_a_500_status_code_and_an_error_message', async () => {
    // Mock an error to be thrown when calling User.create
    const error = new Error('Database error');

    // Mock Express request and response objects
    const req = {
      body: {},
    };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    // Mock the User.create method to reject with an error
    User.create = jest.fn().mockRejectedValue(error);

    // Call the controller function
    await userController.addUser(req, res);

    // Assertions
    expect(User.create).toHaveBeenCalledWith(req.body);
    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({ message: 'Database error' });
  });
});

describe('getAllUsers', () => {
    // 5.User Controller Tests
  test('backend_getallusers_should_return_users_and_respond_with_a_200_status_code', async () => {
    // Sample user data
    const usersData = [
      {
        _id: 'user1',
        username: 'john_doe',
        email: 'john@example.com',
        password: 'hashed_password1',
      },
      {
        _id: 'user2',
        username: 'jane_doe',
        email: 'jane@example.com',
        password: 'hashed_password2',
      },
    ];

    // Mock Express request and response objects
    const req = {};
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    // Mock the User.find method to resolve with the sample user data
    User.find = jest.fn().mockResolvedValue(usersData);

    // Call the controller function
    await userController.getAllUsers(req, res);

    // Assertions
    expect(User.find).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith({"users" : usersData});
  });

    // 6.User Controller Tests
  test('backend_getallusers_should_handle_errors_and_respond_with_a_500_status_code_and_an_error_message', async () => {
    // Mock an error to be thrown when calling User.find
    const error = new Error('Database error');

    // Mock Express request and response objects
    const req = {};
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    // Mock the User.find method to reject with an error
    User.find = jest.fn().mockRejectedValue(error);

    // Call the controller function
    await userController.getAllUsers(req, res);

    // Assertions
    expect(User.find).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({ message: 'Database error' });
  });
});

// 1.User Model Tests
describe('User_Model_Schema_Validation', () => {
  test('backend_user_model_should_validate_a_user_with_valid_data', async () => {
    const validUserData = {
      firstName: 'John',
      lastName: 'Doe',
      mobileNumber: '1234567890',
      email: 'john.doe@example.com',
      role: 'user',
      password: 'validpassword',
    };

    const user = new User(validUserData);

    // Validate the user data against the schema
    await expect(user.validate()).resolves.toBeUndefined();
  });

  // 2.User Model Tests
  test('backend_user_model_should_validate_a_user_with_missing_required_fields', async () => {
    const invalidUserData = {
      // Missing required fields
    };

    const user = new User(invalidUserData);

    // Validate the user data against the schema
    await expect(user.validate()).rejects.toThrowError();
  });

  // 3.User Model Tests
  test('backend_user_model_should_validate_a_user_with_invalid_mobile_number_format', async () => {
    const invalidUserData = {
      firstName: 'John',
      lastName: 'Doe',
      mobileNumber: 'not-a-number',
      email: 'john.doe@example.com',
      role: 'user',
      password: 'validpassword',
    };

    const user = new User(invalidUserData);

    // Validate the user data against the schema
    await expect(user.validate()).rejects.toThrowError(/is not a valid mobile number/);
  });

    // 4.User Model Tests
  test('backend_user_model_should_validate_a_user_with_invalid_email_format', async () => {
    const invalidUserData = {
      firstName: 'John',
      lastName: 'Doe',
      mobileNumber: '1234567890',
      email: 'invalid-email',
      role: 'user',
      password: 'validpassword',
    };

    const user = new User(invalidUserData);

    // Validate the user data against the schema
    await expect(user.validate()).rejects.toThrowError(/is not a valid email address/);
  });

    // 5.User Model Tests
  test('backend_user_model_should_validate_a_user_with_a_password_shorter_than_the_minimum_length', async () => {
    const invalidUserData = {
      firstName: 'John',
      lastName: 'Doe',
      mobileNumber: '1234567890',
      email: 'john.doe@example.com',
      role: 'user',
      password: 'short',
    };

    const user = new User(invalidUserData);

    // Validate the user data against the schema
    await expect(user.validate()).rejects.toThrowError(/is shorter than the minimum allowed length/);
  });
  // 6.User Model Tests
  test('backend_user_model_should_validate_a_user_with_a password_longer_than_the_maximum_length', async () => {
    const invalidUserData = {
      firstName: 'John',
      lastName: 'Doe',
      mobileNumber: '1234567890',
      email: 'john.doe@example.com',
      role: 'user',
      password: 'a'.repeat(256),
    };

    const user = new User(invalidUserData);

    // Validate the user data against the schema
    await expect(user.validate()).rejects.toThrowError(/is longer than the maximum allowed length /);
  });
});




describe('validateToken', () => {
  test('backend_validatetoken_should_respond_with_400_status_and_error_message_if_invalid_token_is_provided', () => {
    // Mock the req, res, and next objects
    const req = {
      header: jest.fn().mockReturnValue('invalidToken'),
    };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };
    const next = jest.fn();

    // Call the validateToken function
    validateToken(req, res, next);

    // Assertions
    expect(req.header).toHaveBeenCalledWith('Authorization');
    expect(next).not.toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({ message: 'Authentication failed' });
  });

  test('backend_validatetoken_should_respond_with_400_status_and_error_message_if_no_token_is_provided', () => {
    // Mock the req, res, and next objects
    const req = {
      header: jest.fn().mockReturnValue(null),
    };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };
    const next = jest.fn();

    // Call the validateToken function
    validateToken(req, res, next);

    // Assertions
    expect(req.header).toHaveBeenCalledWith('Authorization');
    expect(next).not.toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({ message: 'Authentication failed' });
  });
});