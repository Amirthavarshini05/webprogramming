const express = require('express');

const router = express.Router();

const { createTask, getTasks } = require('../controllers/taskController');

// POST /tasks → Create new task

router.post('/', createTask);

// GET /tasks → Get all tasks

router.get('/', getTasks);

module.exports = router;

