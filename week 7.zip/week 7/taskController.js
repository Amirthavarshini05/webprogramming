const Task = require('../models/taskModel');

// Create a new task

const createTask = async (req, res) => {

try {

const { name, description } = req.body;

// Handle missing fields exactly as tests expect

if (!name || !description) {

return res.status(400).json({

message: 'Both name and description are required'

});

}

const newTask = await Task.create({ name, description });

res.status(201).json({

message: 'Task created successfully',

task: newTask

});

} catch (error) {

res.status(500).json({

message: 'Error creating task',

error: error.message

});

}

};

// Get all tasks

const getTasks = async (req, res) => {

try {

const tasks = await Task.find().sort({ createdAt: -1 });

res.status(200).json({

message: 'Tasks retrieved successfully',

tasks,

count: tasks.length

});

} catch (error) {

res.status(500).json({

message: 'Error fetching tasks',

error: error.message

});

}

};

module.exports = { createTask, getTasks };