import React from 'react';

import { Routes, Route } from 'react-router-dom';

import Home from './Components/Home';

import AddTask from './Components/Addtask';

import ViewTasks from './Components/Viewtask';

import './App.css';

function App() {

return (

<div className="App">

<Routes>

<Route path="/" element={<Home />} />

<Route path="/add-task" element={<AddTask />} />

<Route path="/view-tasks" element={<ViewTasks />} />

</Routes>

</div>

);

}

export default App;