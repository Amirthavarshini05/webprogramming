import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

import './Addtask.css';

const AddTask = () => {

const [formData, setFormData] = useState({ name: '', description: '' });

const [message, setMessage] = useState('');

const handleChange = (e) => {

setFormData({ ...formData, [e.target.name]: e.target.value });

};

const handleSubmit = async (e) => {

e.preventDefault();

if (!formData.name || !formData.description) {

setMessage('Please fill in all fields');

return;

}

try {

await axios.post('http://localhost:8080/tasks', formData);

setMessage('Task added successfully!');

setFormData({ name: '', description: '' });

} catch (error) {

setMessage('Error adding task');

}

};

return (

<div className="add-task-container">

<h2>Add New Task</h2>

<form onSubmit={handleSubmit}>

<label htmlFor="name">Task Name:</label>

<input

id="name"

name="name"

type="text"

placeholder="Enter task name"

value={formData.name}

onChange={handleChange}

/>

<label htmlFor="description">Task Description:</label>

<textarea

id="description"

name="description"

placeholder="Enter task description"

value={formData.description}

onChange={handleChange}

/>

<button type="submit">Add Task</button>

</form>

{message && <p className="message">{message}</p>}

<Link to="/" className="back-link">Back to Home</Link>

</div>

);

};

export default AddTask;