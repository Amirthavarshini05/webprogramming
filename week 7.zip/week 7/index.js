
/*const express = require('express');
const taskRouter = require('./taskRouter.js');
const mongoose = require('mongoose');

const app = express.use();

app.use(express.json());
app.use('/task', taskRouter);

mongoose.connect("mongodb://localhost:27017/taskdb")
.then(() => {
console.log("C");
})
.catch((err)=>{
console.log(err)
}

module.exports = app; // for testing if needed
*/

