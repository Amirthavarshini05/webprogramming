import React, { useEffect, useState } from 'react';

import { Link } from 'react-router-dom';

import axios from 'axios';

import './Viewtask.css';

const ViewTasks = () => {

const [tasks, setTasks] = useState([]);

const [loading, setLoading] = useState(true);

const fetchTasks = async () => {

try {

setLoading(true);

const response = await axios.get('http://localhost:8080/tasks');

const data = response.data;

setTasks(data.tasks || []);

} catch (error) {

console.error('Error fetching tasks:', error);

} finally {

setLoading(false);

}

};

useEffect(() => {

fetchTasks();

}, []);

return (

<div className="view-tasks-container">

<h2>All Tasks</h2>

<button onClick={fetchTasks}>Refresh</button>

{loading ? (

<p>Loading tasks...</p>

) : tasks.length === 0 ? (

<p>No tasks found</p>

) : (

<ul className="task-list">

{tasks.map((task) => (

<li key={task._id} className="task-card">

<h3>{task.name}</h3>

<p>{task.description}</p>

</li>

))}

</ul>

)}

<Link to="/" className="back-link">Back to Home</Link>

</div>

);

};

export default ViewTasks;